import React, { useState } from 'react'

export const Login = () => {
  
  const [numero, setNumero] = useState(0);

  const contar = ()=>{
    setNumero(numero+1);
  }
  return (
    <div>login

      <div>{numero}</div>
      <button onClick={contar}>CONTAR</button>
    </div>
  )
}
